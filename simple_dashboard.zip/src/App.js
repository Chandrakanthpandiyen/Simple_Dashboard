import './App.css';
import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { PieChart, Pie, Tooltip, Bar, BarChart, XAxis, YAxis, CartesianGrid, Legend } from 'recharts';

const App = () => {
  const [data, setData] = useState([])

  useEffect(() => {
    axios.get('http://localhost:3031/ABC_Corporation')
      .then(res => setData(res.data))
      .catch(err => console.log(err))

  }, [])

  return (
    <div style={{ textAlign: "center" }}>

      <div className="App">

        {/* PieChart */}
        <PieChart width={400} height={400}>
          <Pie
            dataKey="value"
            isAnimationActive={false}
            data={data}
            cx="50%"
            cy="50%"
            outerRadius={80}
            fill="#808080"
            label 
          />
          <Tooltip/>
        </PieChart>

        {/* BarChart */}
        <BarChart
          width={500}
          height={300}
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
          barSize={20}>

          <XAxis dataKey="Environmental" scale="point" padding={{ left: 10, right: 10 }} />
          <YAxis />
          <Tooltip />
          <Legend />
          <CartesianGrid strokeDasharray="3 3" />
          <Bar dataKey="value" fill="#808080" background={{ fill: '#eee' }} />
        </BarChart>
      </div>
    </div>
  );
}

export default App;
