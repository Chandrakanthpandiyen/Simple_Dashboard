import React, { useEffect, useState } from 'react'
import axios from'axios'

function JsonServer() {
    const [data, setData] = useState([])
    useEffect(()=>{
        axios.get('http://localhost:3031/ABC_Corporation')
        .then(res => setData(res.data))
        .catch(err => console.log(err))
    },[])
    return(

        <div className='container mt-5'>
             <h1 style={{textAlign: "center"}}>ABC Corporation</h1>
             <br/>
             <h3 style={{textAlign: "center"}}>Environmental</h3>

             {/* Table */}
            <table className='table table-bordered table-dark'>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Environmental</th>
                        <th>value</th>
                        <th>unit</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((d,i)=>{
                        return <tr key={i}>
                            <td>{d.id}</td>
                            <td>{d.Environmental}</td>
                            <td>{d.value}</td>
                            <td>{d.unit }</td>
                        </tr>
                    })}
                </tbody>
            </table>
        </div>
    )
}

export default JsonServer