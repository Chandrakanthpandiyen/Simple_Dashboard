import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { PieChart, Pie, Tooltip, Bar, BarChart, XAxis, YAxis, CartesianGrid, Legend } from 'recharts';

function Governance() {

    const [data, setData] = useState([])
    useEffect(() => {
        axios.get('http://localhost:3031/Governance')
            .then(res => setData(res.data))
            .catch(err => console.log(err))
    }, [])

    return (
        <div className='container mt-5'>
            <h3 style={{ textAlign: "center" }}>Governance</h3>

            {/* Table */}
            <table className='table table-bordered table-dark'>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Governance</th>
                        <th>independentDirectors</th>
                        <th>insideDirectors</th>
                        <th>value</th>
                        <th>unit</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((d, i) => {
                        return <tr key={i}>
                            <td>{d.id}</td>
                            <td>{d.governance}</td>
                            <td>{d.independentDirectors}</td>
                            <td>{d.insideDirectors}</td>
                            <td>{d.value}</td>
                            <td>{d.unit}</td>
                        </tr>
                    })}
                </tbody>
            </table>

            <div className="App">

                {/* PieChart */}
                <PieChart width={400} height={400}>
                    <Pie
                        dataKey="value"
                        isAnimationActive={false}
                        data={data}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        fill="#808080"
                        label
                    />
                    <Tooltip />
                </PieChart>

                {/* BarChart */}
                <BarChart
                    width={500}
                    height={300}
                    data={data}
                    margin={{
                        top: 5,
                        right: 30,
                        left: 20,
                        bottom: 5,
                    }}
                    barSize={20}>

                    <XAxis dataKey="governance" scale="point" padding={{ left: 10, right: 10 }} />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <CartesianGrid strokeDasharray="3 3" />
                    <Bar dataKey="value" fill="#808080" background={{ fill: '#eee' }} />
                </BarChart>
            </div>
        </div>
    )
}

export default Governance